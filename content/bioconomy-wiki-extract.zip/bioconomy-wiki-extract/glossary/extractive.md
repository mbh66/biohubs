---
title: "Extractive"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["regenerative", "throughput-economics", "two-machines"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


Producing value by drawing down the substrate the production depends on.

## Related terms

- [[glossary/regenerative|Regenerative]]
- [[glossary/throughput-economics|Throughput Economics]]
- [[glossary/two-machines|Two Machines]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
