---
title: "Below-dam Position"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["ecological-science", "watershed-mapping"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


A structural geographic position in which a bioregion sits downstream of a major reservoir, converting demand-side coordination (reduced water consumption) into a measurable service for the upstream supply system.

## Related terms

- [[glossary/ecological-science|Ecological science]]
- [[glossary/watershed-mapping|Watershed Mapping]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
