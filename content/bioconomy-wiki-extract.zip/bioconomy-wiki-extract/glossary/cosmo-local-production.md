---
title: "Cosmo-local production"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["bioregional-economics"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


Michel Bauwens's formulation: share knowledge globally, adapt it locally, produce regeneratively in place, share the learning globally.

## Related terms

- [[glossary/bioregional-economics|Bioregional Economics]]

## Sources and associated figures

- [[people/michel-bauwens|Michel Bauwens]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
