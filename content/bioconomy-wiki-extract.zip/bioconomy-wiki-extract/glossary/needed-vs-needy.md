---
title: "Needed vs. Needy"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["bioregional-economics", "needy", "needed"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


The structural distinction between a bioregion that asks funders for money to do restoration work (needy) and one that tenders a verified ecological service into a market already structured to purchase it (needed).

## Related terms

- [[glossary/bioregional-economics|Bioregional Economics]]
- [[glossary/needy|Needy]]
- [[glossary/needed|Needed]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
