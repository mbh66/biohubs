---
title: "P4P (Peer FOR Peer)"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["e-form-emergent"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


Jeff Emmett's coinage, adopted by Michel Bauwens, naming the transition from peer-to-peer (horizontal digital exchange) to peer-for-peer or community-to-community (place-based coordination for mutual benefit).

## Related terms

- [[glossary/e-form-emergent|E form (Emergent)]]

## Sources and associated figures

- [[people/michel-bauwens|Michel Bauwens]]
- [[people/jeff-emmett|Jeff Emmett]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
