---
title: "TIMN Framework"
aliases: []
tags: ["glossary", "framework"]
term_type: "framework"
first_defined_in: ""
related_terms: ["time-framework", "human-coordination"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


TIMN is a theoretical framework that categorizes the evolution of societal organization into four fundamental forms: Tribes (T), Institutions (I), Markets (M), and Networks (N).

## Definition

Each of these forms represents a distinct system of beliefs, structures, and dynamics that influence how societies are organized and function.

## Related terms

- [[glossary/time-framework|TIME Framework]]
- [[glossary/human-coordination|Human Coordination]]

## Sources and associated figures

- [[people/david-ronfeldt|David Ronfeldt]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Research, Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
