---
title: "Strategic Water Source Area (SWSA)"
aliases: ["Strategic Water Source Area", "SWSA"]
tags: ["glossary"]
term_type: "acronym"
first_defined_in: ""
related_terms: ["ecological-science"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


A designation identifying areas that supply a disproportionate share of a country's water relative to their size, requiring targeted protection and restoration.

## Related terms

- [[glossary/ecological-science|Ecological science]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
