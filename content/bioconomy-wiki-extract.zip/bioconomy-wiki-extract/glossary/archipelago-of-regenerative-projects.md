---
title: "Archipelago of Regenerative Projects"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["e-form-emergent"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


Bauwens' framing of the emerging field as a third attractor alongside Chinese state cybernetics and Western platform cybernetics.

## Related terms

- [[glossary/e-form-emergent|E form (Emergent)]]

## Sources and associated figures

- [[people/michel-bauwens|Michel Bauwens]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
