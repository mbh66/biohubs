---
title: "Indigenous Knowledge"
aliases: []
tags: ["glossary"]
term_type: "borrowed-technical"
first_defined_in: ""
related_terms: ["t-form-tribal", "intelligence-carbon"]
source_project: "BioConomy"
created: 2026-08-24
updated: 2026-08-24
epistemic_status: "documented-framework"
---


Knowledge that arises from sustained relationship with a specific place: its soils, water, seasons, species, and patterns of change observed over generations.

## Related terms

- [[glossary/t-form-tribal|T form (Tribal)]]
- [[glossary/intelligence-carbon|Intelligence, Carbon]]

## Provenance

Extracted from the BioHub Glossary CSV export (Notion, August 2026). Source cell classified as `Term`. First-pass entry: the extended definition, contrast with adjacent terms, and usage-in-context sections require enrichment from the underlying project documents on a subsequent pass.
